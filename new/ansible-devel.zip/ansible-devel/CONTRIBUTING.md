# WELCOME TO ANSIBLE GITHUB

Hi! Nice to see you here!


## QUESTIONS ?

Please see the [community page](http://docs.ansible.com/community.html) for information on how to ask questions on the [mailing lists](http://docs.ansible.com/community.html#mailing-list-information) and IRC.

The GitHub issue tracker is not the best place for questions for various reasons, but both IRC and the mailing list are very helpful places for those things, as the community page explains best.


## CONTRIBUTING ?

Please see the [community page](http://docs.ansible.com/community.html) for information regarding the contribution process. Important license agreement information is also included on that page.


## BUG TO REPORT ?

First and foremost, also check the [community page](http://docs.ansible.com/community.html).

You can report bugs or make enhancement requests at the [Ansible GitHub issue page](http://github.com/ansible/ansible/issues/new) by filling out the issue template that will be presented.

Also please make sure you are testing on the latest released version of Ansible or the development branch. You can find the latest releases and development branch at:

- https://github.com/ansible/ansible/releases
- https://github.com/ansible/ansible/archive/devel.tar.gz

Thanks!
